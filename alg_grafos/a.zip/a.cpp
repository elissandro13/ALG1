#include <bits/stdc++.h>

using namespace std;
#define f first
#define s second

struct Ponto {
    double x, y;
};

class Aresta;

class Vertice {
private:
    int id;
    Ponto cord;
    vector<Aresta*> lista_arestas;

public:
    Vertice(int _id = 0, double _x = 0, double _y = 0) : id(_id), cord{_x, _y} {}

    int getId() const {
        return id;
    }

    Ponto getCord() const {
        return cord;
    }

    void setCord(const Ponto& _cord) {
        cord = _cord;
    }

    vector<Aresta*>& getListaArestas() {
        return lista_arestas;
    }
};

class Aresta {
private:
    Vertice* v1;
    Vertice* v2;
    bool visitada;

public:
    Aresta(Vertice* _v1 = nullptr, Vertice* _v2 = nullptr) : v1(_v1), v2(_v2), visitada(false) {}

    Vertice* getV1() const {
        return v1;
    }

    Vertice* getV2() const {
        return v2;
    }

    void setV2(Vertice* _v2) {
        v2 = _v2;
    }

    bool isVisitada() const {
        return visitada;
    }

    void setVisitada(bool _visitada) {
        visitada = _visitada;
    }
};

double inclinacaoRelativa(const Ponto& p, const Ponto& q) {
    return atan2(q.y - p.y, q.x - p.x);
}

int TipoCurva(const Ponto& a, const Ponto& b, const Ponto& c) {
    double v = a.x * (b.y - c.y) + b.x * (c.y - a.y) + c.x * (a.y - b.y);
    if (v < 0) return -1; // a está à esquerda de b
    if (v > 0) return +1; // a está à direita de b
    return 0; // a, b, c são colineares (em frente)
}

bool compararInclinacao(const Ponto& a, const Ponto& b, const Ponto& A, const Ponto& B) {
    double anguloA = inclinacaoRelativa(B, A);
    double angulo1 = inclinacaoRelativa(B, a) - anguloA;
    double angulo2 = inclinacaoRelativa(B, b) - anguloA;

    if (angulo1 < 0) angulo1 += 2 * M_PI;
    if (angulo2 < 0) angulo2 += 2 * M_PI;

    // Usando TipoCurva para determinar a orientação relativa
    int tipo = TipoCurva(a, b, A);
    if (tipo == -1) return false; // a está à esquerda de b
    if (tipo == +1) return true;  // a está à direita de b

    // Caso estejam em frente ou na mesma linha
    return angulo1 < angulo2;
}

void sortAntiHorario(Vertice* A, Vertice* B) {
    vector<pair<Ponto, Aresta*>> pontosEArestdas;

    for (auto& aresta : B->getListaArestas()) {
        pontosEArestdas.push_back(make_pair(aresta->getV2()->getCord(), aresta));
    }

    sort(pontosEArestdas.begin(), pontosEArestdas.end(), [&](const pair<Ponto, Aresta*>& a, const pair<Ponto, Aresta*>& b) {
        return compararInclinacao(a.f, b.f, A->getCord(), B->getCord());
    });

    for (size_t i = 0; i < B->getListaArestas().size(); i++) {
        B->getListaArestas()[i] = pontosEArestdas[i].s;
    }
}

int main() {
    int numVertices, numArestas;
    
    scanf("%d %d", &numVertices, &numArestas);

    vector<Vertice*> vertices;
    vector<vector<int>> listasAdjacencia(numVertices);
    vector<Aresta*> arestas;
    vector<vector<Vertice*>> faces;

    for (int i = 0; i < numVertices; i++) {
        double x, y;
        int grau;
        scanf("%lf %lf %d", &x, &y, &grau);
        vertices.push_back(new Vertice(i + 1, x, y));

        for (int j = 0; j < grau; j++) {
            int adjacente;
            scanf("%d", &adjacente);
            listasAdjacencia[i].push_back(adjacente - 1);
        }
    }

    

    for (int i = 0; i < numVertices; i++) {
        for (int adj : listasAdjacencia[i]) {
            Aresta* nova = new Aresta(vertices[i], vertices[adj]);
            arestas.push_back(nova);
            vertices[i]->getListaArestas().push_back(nova);
        }
    }

    

    for (auto& inicial : arestas) {
        if (inicial->isVisitada()) continue;

        Aresta* atual = inicial;
        vector<Vertice*> face;

        face.push_back(inicial->getV1());
        while (!atual->isVisitada()) {
            face.push_back(atual->getV2());
            atual->setVisitada(true);

            sortAntiHorario(atual->getV1(), atual->getV2());

            for (auto& prox : atual->getV2()->getListaArestas()) {
                if (prox->getV2() != atual->getV1() || atual->getV2()->getListaArestas().size() < 2) {
                    atual = prox;
                    break;
                }
            }
        }

        faces.push_back(face);
    }

    printf("%lu\n", faces.size());
    for (const auto& face : faces) {
        printf("%lu ", face.size());
        for (const auto& vertice : face) {
            printf("%d ", vertice->getId());
        }
        printf("\n");
    }

    for (auto aresta : arestas) {
        delete aresta;
    }

    for (auto vertice : vertices) {
        delete vertice;
    }

    return 0;
}
